import numpy as np
import matplotlib.pyplot as plt

# Load the approximated eigenvalues (one per line) from the file.
data = np.loadtxt("cfd1-serial.txt")

# Generate iteration numbers assuming iterations increase by 20.
iterations = np.arange(20, 20*(len(data)+1), 20)

# Gershgorin upper bound (given)
gersh_bound = 8.920231

plt.figure(figsize=(8, 6))
plt.plot(iterations, data, marker='o', linestyle='-', color='blue',
         label='Power Iteration Approximation')
plt.axhline(y=gersh_bound, color='red', linestyle='--',
            label='Gershgorin Upper Bound (8.920231)')

plt.xlabel("Iteration")
plt.ylabel("Approximated Spectral Radius")
plt.title("Evolution of Approximated Spectral Radius (Log Scale)")
plt.legend()
plt.grid(True)

# Set the y-axis to logarithmic scale.
plt.yscale("log")
plt.tight_layout()
plt.show()
