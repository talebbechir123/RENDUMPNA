#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "mmio.h"
#include <math.h>
#include <string.h>






typedef struct {
    int n;
    int m;
    int *row_ptr;
    int *col_idx;
    double *val;
} csr_matrix;



void readMMF(const char *filename, csr_matrix *A) {
    MM_typecode matcode;
    FILE *f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "Error opening file %s\n", filename);
        exit(1);
    }
    
  //  printf("3\n");
    // Read banner
    if (mm_read_banner(f, &matcode) != 0) {
        printf("Could not process Matrix Market banner.\n");
        exit(1);
    }
   // printf("4\n");

    // Check if it's sparse, real, and symmetric
    if (!mm_is_sparse(matcode) || !mm_is_real(matcode) || !mm_is_symmetric(matcode)) {
        printf("Matrix must be sparse, real, and symmetric.\n");
        exit(1);
    }
   // printf("5\n");

    // Read dimensions and number of entries in the triangular part
    int M, N, nz;
    if (mm_read_mtx_crd_size(f, &M, &N, &nz) != 0) {
        printf("Error reading matrix size.\n");
        exit(1);
    }
    //printf("6\n");

    // Allocate temporary COO arrays (for the triangular portion)
    int *I = (int*)malloc(nz * sizeof(int));
    int *J = (int*)malloc(nz * sizeof(int));
    double *V = (double*)malloc(nz * sizeof(double));
    
  //  printf("7\n");
    // Read the (i, j, value) lines and convert indices to 0-based.
    for (int i = 0; i < nz; i++) {
        fscanf(f, "%d %d %lf", &I[i], &J[i], &V[i]);
        I[i]--;
        J[i]--;
    }
    fclose(f);
  //  printf("8\n");
    
    // Count how many off-diagonal entries (to mirror them)
    int offDiag = 0;
    for (int k = 0; k < nz; k++) {
        if (I[k] != J[k]) {
            offDiag++;
        }
    }
   // printf("9\n");
    int totalEntries = nz + offDiag; // expected total CSR entries

    // Allocate CSR structure arrays.
    A->n = M;
    A->m = N;
    A->row_ptr = (int*)malloc((M + 1) * sizeof(int));
    A->col_idx = (int*)malloc(totalEntries * sizeof(int));
    A->val     = (double*)malloc(totalEntries * sizeof(double));
    
   // printf("10\n");
    // Use a temporary count array to compute row counts.
    int *count = (int*)calloc(M, sizeof(int));
    for (int k = 0; k < nz; k++) {
        count[I[k]]++;
        if (I[k] != J[k])
            count[J[k]]++;
    }
    A->row_ptr[0] = 0;
    for (int i = 0; i < M; i++) {
        A->row_ptr[i + 1] = A->row_ptr[i] + count[i];
    }
    free(count);
   // printf("11\n");

    // Debug print: ensure A->row_ptr[M] == totalEntries.
    if (A->row_ptr[M] != totalEntries) {
        printf("Warning: row_ptr[M] (%d) does not equal totalEntries (%d).\n", A->row_ptr[M], totalEntries);
    } else {
        printf("Total entries: %d\n", totalEntries);
    }
   // printf("12\n");
    
    // Allocate a temporary array "current" to track current insertion index for each row.
    int *current = (int*)malloc(M * sizeof(int));
    memcpy(current, A->row_ptr, M * sizeof(int));
    
    // Fill the CSR arrays.
    for (int k = 0; k < nz; k++) {
        int r = I[k];
        int c = J[k];
        double v = V[k];
        
        // Insert (r, c, v)
        int destPos = current[r];
        A->col_idx[destPos] = c;
        A->val[destPos]     = v;
        current[r]++;
        
        // If off-diagonal, insert mirrored entry (c, r, v)
        if (r != c) {
            destPos = current[c];
            A->col_idx[destPos] = r;
            A->val[destPos]     = v;
            current[c]++;
        }
    }
    
   // printf("13\n");
    free(current);
    free(I);
    free(J);
    free(V);
    //printf("14\n");
    printf("Matrix read successfully in full symmetric form.\n");
}




//function to read a vector from a file
void readVec(char *filename ,double vec[], int n){
    FILE *f = fopen(filename,"r");
    if(f == NULL){
        printf("Error opening file %s\n",filename);
        exit(1);
    }
    for(int i = 0; i < n; i++){
        fscanf(f,"%lf",&vec[i]);
    }
    fclose(f);
}


// Compute the Euclidean norm (L2 norm) of a vector of length n.
double vector_norm(int n, double* x) {
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += x[i] * x[i];
    }
    return sqrt(sum);
}

// Scale a vector x (of length n) by a constant factor.
void scale_vector(int n, double* x, double scale) {
    for (int i = 0; i < n; i++) {
        x[i] *= scale;
    }
}

// Compute the dot product of two vectors of length n.
double dot_product(int n, double* x, double* y) {
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += x[i] * y[i];
    }
    return sum;
}



//function to multiply a csr matrix with a vector
// void matVec(csr_matrix *A, double x[], double y[]){
//     printf("MatVec-debug_1\n");
//     int n = A->n;
//     printf("MatVec-debug_2\n");
//     for(int i = 0; i < n; i++){
//         y[i] = 0;
//         for(int j = A->row_ptr[i]; j < A->row_ptr[i+1]; j++){
//             y[i] += A->val[j] * x[A->col_idx[j]];
//         }
//     }
// }
void matVec(csr_matrix *A, double x[], double y[]){
   // printf("MatVec-debug_1\n");
    int n = A->n;
    int m = A->m;  // global number of columns
  //  printf("MatVec-debug_2: n = %d, m = %d\n", n, m);
    
    for (int i = 0; i < n; i++){
        y[i] = 0.0;
        int row_start = A->row_ptr[i];
        int row_end = A->row_ptr[i+1];
        // Debug: print row boundaries
        // printf("Row %d: start=%d, end=%d\n", i, row_start, row_end);
        for (int j = row_start; j < row_end; j++){
            int col = A->col_idx[j];
            if(col < 0 || col >= m) {
                fprintf(stderr, "Error: Invalid column index %d at row %d, position %d\n", col, i, j);
                exit(1);
            }
            y[i] += A->val[j] * x[col];
        }
    }
  //  printf("MatVec-debug completed.\n");
}




double PowerIteration(csr_matrix *A, double x[], int max_iter) {
   // printf("Power Iteration X\n");
    int n = A->n;
    double *y = (double *)malloc(n * sizeof(double));
    if (y == NULL) {
        fprintf(stderr, "Memory allocation error.\n");
        exit(EXIT_FAILURE);
    }
    
    double lambda = 0.0;
    
    // Initialize x randomly and normalize it.
    srand((unsigned)time(NULL));
    double norm = 0.0;
    for (int i = 0; i < n; i++) {
        x[i] = (double)rand() / (double)RAND_MAX;
       
    }
   
    
    // Power iteration loop.
    for (int iter = 0; iter < max_iter; iter++){
        // y = A*x
        matVec(A, x, y);
        
        // Compute norm of y.
        double y_norm = vector_norm(n, y);
        
        // Approximate eigenvalue: since x is normalized,
        // we have A*x ≈ λ*x so that ||A*x|| ≈ |λ|
        lambda = y_norm;

        // Normalize y for next iteration.
        for (int i = 0; i < n; i++){
            x[i] = y[i] / y_norm;
        }
    }
    
    free(y);
    return lambda;
}



// double powerIteration_old(const csr_matrix *A,
//                       double *x,        // user-allocated vector, size A->n
//                       int max_iter,
//                       double tol)
// {
//     int n = A->n;
//     double *y = (double *)malloc(n * sizeof(double));
//     if(!y) {
//         fprintf(stderr, "Allocation error in powerIteration.\n");
//         exit(1);
//     }

//     // We start with a random or user-provided x. (Here, let's do random.)
//     srand((unsigned)time(NULL));
//     for(int i = 0; i < n; i++) {
//         x[i] = (double)rand() / RAND_MAX;
//     }

//     // We'll track the old and new eigenvalue estimates.
//     double lambda_old = 1.0;
//     double lambda_new = 0.0;

//     // Start iteration
//     for(int iter = 1; iter <= max_iter; iter++) {
//         // (a) y = A * x
//         matVec(A, x, y);

//         // (b) find largest abs value in y -> that's our lambda_new
//         lambda_new = fabs(y[0]);
//         for(int i = 1; i < n; i++) {
//             double val_abs = fabs(y[i]);
//             if(val_abs > lambda_new) {
//                 lambda_new = val_abs;
//             }
//         }

//         // (c) normalize y by dividing each entry by lambda_new
//         //     to get the next x
//         if(lambda_new < 1e-14) {
//             // x is nearly the zero vector => break
//             fprintf(stderr, "Warning: x is near zero. Stopping.\n");
//             break;
//         }
//         for(int i = 0; i < n; i++) {
//             x[i] = y[i] / lambda_new;
//         }

//         // (d) check for convergence
//         if(fabs(lambda_new - lambda_old) < tol) {
//             printf("Converged at iteration %d\n", iter);
//             break;
//         }

//         // (e) update lambda_old
//         lambda_old = lambda_new;
//     }

//     free(y);
//     return lambda_new;
// }


// Power iteration that returns the eigenvector and prints the largest eigenvalue
double* PIV(csr_matrix* A, double *x, int max_iter) {
    int n = A->n;
   // printf("Power Iteration X%d\n",n);
    double *y = (double*)malloc(n * sizeof(double));
    if (y == NULL) {
        fprintf(stderr, "Memory allocation error.\n");
        exit(EXIT_FAILURE);
    }
  //  printf("Power Iteration X3\n");

    // Randomize x
    srand((unsigned)time(NULL));
    for (int i = 0; i < n; i++) {
        x[i] = (double)rand() / (double)RAND_MAX;
    }
   // printf("Power Iteration X4\n");

    // Normalize initial x
    {
        double norm_x = vector_norm(n, x);
        if (norm_x > 0) {
            for (int i = 0; i < n; i++) {
                x[i] /= norm_x;
            }
        }
    }

  //  printf("Power Iteration X5\n");

    // Power iteration loop
    for (int iter = 0; iter < max_iter; iter++) {
      //  printf("Power Iteration X6\n");
        // y = A*x
        matVec(A, x, y);
      //  printf("Power Iteration X7\n");

        // Compute norm of y and normalize
        double y_norm = vector_norm(n, y);
        if (y_norm > 1e-6) {
            for (int i = 0; i < n; i++) {
                x[i] = y[i] / y_norm;
            }
        } else {
            // Handle a zero vector or near-zero norm
            fprintf(stderr, "Warning: x is near zero. Stopping.\n");
            break;
        }
    }

      

    // After final iteration, approximate largest eigenvalue via Rayleigh quotient
    // lambda ~ x^T A x
    matVec(A, x, y); 
    double lambda = dot_product(n, x, y);
    printf("Approx. Largest Eigenvalue: %f\n", lambda);

    free(y);
    return x;

}


double gershgorin_upper_bound(csr_matrix *A) {
    int n = A->n;
    double max_bound = -INFINITY;
    for (int i = 0; i < n; i++){
        double diag = 0.0;
        double off_sum = 0.0;
        for (int j = A->row_ptr[i]; j < A->row_ptr[i+1]; j++){
            int col = A->col_idx[j];
            double val = fabs(A->val[j]);
            if (col == i)
                diag = val;
            else
                off_sum += val;
        }
        double bound = diag + off_sum;
        if (bound > max_bound)
            max_bound = bound;
    }
    return max_bound;
}









int main(int argc,char ** argv){
     

    if(argc < 3){
        printf("Usage: %s <matrix-file>\n",argv[0]);
        exit(1);
    }
    //printf("0\n");



   char *matrixFile = argv[1];
   int max_iter = atoi(argv[2]);

    //test the readMMF function
    csr_matrix A;
    //readMMF("data/cfd1/cfd1.mtx",&A);
    ///readMMF("data/bcsstk03/bcsstk03.mtx",&A);
     //const char *matrixFile = "data/1138_bus.mtx";
  //  printf("1\n");
    readMMF(matrixFile,&A);
    //printf("2\n");
    //readMMF("test.mtx",&A);
   // printf("Matrix size: %d x %d\n",A.n,A.m);
    //let test the power iteration method
    double x[A.n];
    // printf("X2\n");
   // readVec("vector.txt",x,A.n);
    //int max_iter = 50;
    //double lambda = PowerIteration(&A,x,max_iter);
    //double lambda = powerIteration_simplified(&A,x,max_iter);
    //double lambda = powerIteration_old(&A,x,max_iter,1e-6);
    
    
  //  printf("Largest eigenvalue: %lf\n",lambda);
    printf("--------------------------------\n");
    double *eigenvector = PIV(&A, x, max_iter);
   // printf("Eigen vector found\n"); 

    // Compute the Gershgorin upper bound
    double gersh_bound = gershgorin_upper_bound(&A);

    printf("Gershgorin upper bound: %f\n", gersh_bound);
   




   
   



    return 0;
}