// #include <mpi.h>
// #include <stdio.h>
// #include <stdlib.h>
// #include <math.h>
// #include <time.h>
// #include <string.h>
// #include "mmio.h" 


// typedef struct {
//     int n;          // number of rows
//     int m;          // number of columns (for square matrices, n == m)
//     int *row_ptr;   // size: n+1
//     int *col_idx;   // size: number of nonzeros
//     double *val;    // size: number of nonzeros
// } csr_matrix;

//  // Local CSR block 

// typedef struct {
//     int n_global;   // global dimension (number of rows in full matrix)
//     int n_local;    // number of rows on this rank
//     int row_offset; // starting global row index for this rank
//     int *row_ptr;   // local row_ptr (size: n_local+1)
//     int *col_idx;   // local column indices (size: local nnz)
//     double *val;    // local nonzero values (size: local nnz)
// } csr_block;


// void readMMFSerial(const char *filename, csr_matrix *A) 
// {
//     MM_typecode matcode;
//     FILE *f = fopen(filename, "r");
//     if (!f) {
//         fprintf(stderr, "Error opening file %s\n", filename);
//         exit(1);
//     }
//     if (mm_read_banner(f, &matcode) != 0) {
//         printf("Could not process Matrix Market banner.\n");
//         exit(1);
//     }
//     if (!mm_is_sparse(matcode) || !mm_is_real(matcode) || !mm_is_symmetric(matcode)) {
//         printf("Matrix must be sparse, real, and symmetric.\n");
//         exit(1);
//     }
//     int M, N, nz;
//     if (mm_read_mtx_crd_size(f, &M, &N, &nz) != 0) {
//         printf("Error reading matrix size.\n");
//         exit(1);
//     }
//     int *I = (int*)malloc(nz * sizeof(int));
//     int *J = (int*)malloc(nz * sizeof(int));
//     double *val = (double*)malloc(nz * sizeof(double));
//     for (int i = 0; i < nz; i++) {
//         fscanf(f, "%d %d %lf", &I[i], &J[i], &val[i]);
//         I[i]--;  // convert to 0-based indexing
//         J[i]--;
//     }
//     fclose(f);
//     int offDiag = 0;
//     for (int i = 0; i < nz; i++){
//         if (I[i] != J[i]) offDiag++;
//     }
//     int totalEntries = nz + offDiag;
//     A->n = M;
//     A->m = N;
//     A->row_ptr = (int*)calloc(M+1, sizeof(int));
//     A->col_idx = (int*)malloc(totalEntries * sizeof(int));
//     A->val     = (double*)malloc(totalEntries * sizeof(double));
//     for (int k = 0; k < nz; k++) {
//         A->row_ptr[I[k]]++;
//         if (I[k] != J[k])
//             A->row_ptr[J[k]]++;
//     }
//     for (int r = 0; r < M; r++){
//         A->row_ptr[r+1] += A->row_ptr[r];
//     }
//     int *row_pos = (int*)calloc(M, sizeof(int));
//     for (int k = 0; k < nz; k++){
//         int r = I[k], c = J[k];
//         double v = val[k];
//         int dest = A->row_ptr[r] + row_pos[r];
//         A->col_idx[dest] = c;
//         A->val[dest]     = v;
//         row_pos[r]++;
//         if (r != c) {
//             dest = A->row_ptr[c] + row_pos[c];
//             A->col_idx[dest] = r;
//             A->val[dest]     = v;
//             row_pos[c]++;
//         }
//     }
//    // free(row_pos);
//     //free(I);
//     //free(J);
//     //free(val);
//     printf("Serial read of matrix '%s' complete (%d x %d, %d total entries).\n",
//            filename, M, N, totalEntries);
// }

// /*---------------------------
//   localMatVec:
//   Multiply local CSR block A by global vector x.
//   Result is stored in y_local.
// ----------------------------*/
// void localMatVec(const csr_block *A, const double *x_global, double *y_local) {
//     for (int i = 0; i < A->n_local; i++){
//         double sum = 0.0;
//         int start = A->row_ptr[i];
//         int end   = A->row_ptr[i+1];
//         for (int k = start; k < end; k++){
//             int col = A->col_idx[k];
//             sum += A->val[k] * x_global[col];
//         }
//         y_local[i] = sum;
//     }
// }


// double vector_norm(const double *v, int n) {
//     double sum = 0.0;
//     for (int i = 0; i < n; i++){
//         sum += v[i]*v[i];
//     }
//     return sqrt(sum);
// }


// double dot_product(const double *a, const double *b, int n) {
//     double sum = 0.0;
//     for (int i = 0; i < n; i++){
//         sum += a[i]*b[i];
//     }
//     return sum;
// }

// /*---------------------------
//   distributeCSR:
//   Distribute the full CSR matrix (held on root) to all processes.
//   Each process receives its block of contiguous rows.
  
//   For each non-root process, rank 0 sends its own local nnz (using tag 99)
//   and then sends the local CSR arrays.
  
//   We ensure that even if the local nnz is 0, we allocate at least one element.
// ----------------------------*/
// void distributeCSR(const csr_matrix *Afull, csr_block *Ablock, MPI_Comm comm) {
//     int rank, size;
//     MPI_Comm_rank(comm, &rank);
//     MPI_Comm_size(comm, &size);
    
//     int n_global;
//     if (rank == 0)
//         n_global = Afull->n;
//     else
//         n_global = 0;
//     MPI_Bcast(&n_global, 1, MPI_INT, 0, comm);
    
//     int rows_per_proc = (n_global + size - 1) / size;
//     int start_row = rank * rows_per_proc;
//     int end_row = (rank+1) * rows_per_proc;
//     if (end_row > n_global) end_row = n_global;
//     Ablock->n_global = n_global;
//     Ablock->n_local = end_row - start_row;
//     Ablock->row_offset = start_row;
    
//     int local_nnz;
//     if (rank == 0) {
//         local_nnz = 0;
//         for (int r = start_row; r < end_row; r++){
//             local_nnz += Afull->row_ptr[r+1] - Afull->row_ptr[r];
//         }
//     } else {
//         MPI_Recv(&local_nnz, 1, MPI_INT, 0, 99, comm, MPI_STATUS_IGNORE);
//     }
//     /* Ensure we allocate at least one element when local_nnz is 0 */
//     Ablock->row_ptr = (int*) malloc((Ablock->n_local + 1) * sizeof(int));
//     Ablock->col_idx = (int*) malloc((local_nnz > 0 ? local_nnz : 1) * sizeof(int));
//     Ablock->val     = (double*) malloc((local_nnz > 0 ? local_nnz : 1) * sizeof(double));
    
//     if (rank == 0) {
//         int prefix = 0;
//         Ablock->row_ptr[0] = 0;
//         for (int i = 0; i < Ablock->n_local; i++){
//             int r = start_row + i;
//             int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
//             prefix += row_len;
//             Ablock->row_ptr[i+1] = prefix;
//         }
//         int idx = 0;
//         for (int r = start_row; r < end_row; r++){
//             int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
//             int pos = Afull->row_ptr[r];
//             memcpy(&Ablock->col_idx[idx], &Afull->col_idx[pos], row_len * sizeof(int));
//             memcpy(&Ablock->val[idx], &Afull->val[pos], row_len * sizeof(double));
//             idx += row_len;
//         }
//         /* Send blocks to other processes */
//         for (int other = 1; other < size; other++) {
//             int o_start = other * rows_per_proc;
//             int o_end = (other+1) * rows_per_proc;
//             if (o_end > n_global) o_end = n_global;
//             int o_n_local = o_end - o_start;
//             int o_local_nnz = 0;
//             for (int r = o_start; r < o_end; r++){
//                 o_local_nnz += Afull->row_ptr[r+1] - Afull->row_ptr[r];
//             }
//             MPI_Send(&o_local_nnz, 1, MPI_INT, other, 99, comm);
//             int *tmp_row_ptr = (int*) malloc((o_n_local + 1) * sizeof(int));
//             tmp_row_ptr[0] = 0;
//             int prefix_o = 0;
//             for (int i = 0; i < o_n_local; i++){
//                 int r = o_start + i;
//                 int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
//                 prefix_o += row_len;
//                 tmp_row_ptr[i+1] = prefix_o;
//             }
//             int *tmp_col = (int*) malloc((o_local_nnz > 0 ? o_local_nnz : 1) * sizeof(int));
//             double *tmp_val = (double*) malloc((o_local_nnz > 0 ? o_local_nnz : 1) * sizeof(double));
//             int idx2 = 0;
//             for (int r = o_start; r < o_end; r++){
//                 int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
//                 int pos = Afull->row_ptr[r];
//                 memcpy(&tmp_col[idx2], &Afull->col_idx[pos], row_len * sizeof(int));
//                 memcpy(&tmp_val[idx2], &Afull->val[pos], row_len * sizeof(double));
//                 idx2 += row_len;
//             }
//             MPI_Send(tmp_row_ptr, o_n_local+1, MPI_INT, other, 100, comm);
//             MPI_Send(tmp_col, o_local_nnz, MPI_INT, other, 101, comm);
//             MPI_Send(tmp_val, o_local_nnz, MPI_DOUBLE, other, 102, comm);
//             free(tmp_row_ptr);
//             free(tmp_col);
//             free(tmp_val);
//         }
//     } else {
//         MPI_Recv(Ablock->row_ptr, Ablock->n_local+1, MPI_INT, 0, 100, comm, MPI_STATUS_IGNORE);
//         MPI_Recv(Ablock->col_idx, local_nnz, MPI_INT, 0, 101, comm, MPI_STATUS_IGNORE);
//         MPI_Recv(Ablock->val, local_nnz, MPI_DOUBLE, 0, 102, comm, MPI_STATUS_IGNORE);
//     }
// }

// /*---------------------------
//   parallelPowerIteration:
//   Use a replicated global vector x.
//   Each process computes y_local = A_local*x, then updates and broadcasts x.
//   Finally, compute the Rayleigh quotient.
// ----------------------------*/
// void parallelPowerIteration(const csr_block *A, double *x_global, int max_iter, MPI_Comm comm)
// {
//     int rank;
//     MPI_Comm_rank(comm, &rank);
//     double *y_local = (double*) malloc(A->n_local * sizeof(double));
    
//     /* Initialize x_global on rank 0 and broadcast */
//     if (rank == 0) {
//         srand((unsigned)time(NULL));
//         for (int i = 0; i < A->n_global; i++){
//             x_global[i] = (double)rand() / RAND_MAX;
//         }
//     }
//     MPI_Bcast(x_global, A->n_global, MPI_DOUBLE, 0, comm);
    
//     /* Normalize x_global */
//     double local_sum = 0.0;
//     for (int i = 0; i < A->n_global; i++){
//         local_sum += x_global[i] * x_global[i];
//     }
//     double global_sum = 0.0;
//     MPI_Allreduce(&local_sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, comm);
//     double norm_init = sqrt(global_sum);
//     for (int i = 0; i < A->n_global; i++){
//         x_global[i] /= norm_init;
//     }
//     MPI_Bcast(x_global, A->n_global, MPI_DOUBLE, 0, comm);
    
//     for (int iter = 0; iter < max_iter; iter++){
//         /* Compute y_local = A_local * x_global */
//         localMatVec(A, x_global, y_local);
        
//         /* Compute norm of y_local over all processes */
//         double local_norm_sq = 0.0;
//         for (int i = 0; i < A->n_local; i++){
//             local_norm_sq += y_local[i] * y_local[i];
//         }
//         double global_norm_sq = 0.0;
//         MPI_Allreduce(&local_norm_sq, &global_norm_sq, 1, MPI_DOUBLE, MPI_SUM, comm);
//         double y_norm = sqrt(global_norm_sq);
        
//         /* Update local portion of x_global */
//         for (int i = 0; i < A->n_local; i++){
//             int global_row = A->row_offset + i;
//             x_global[global_row] = y_local[i] / y_norm;
//         }
//         MPI_Bcast(x_global, A->n_global, MPI_DOUBLE, 0, comm );// adjust path as neededm);
//     }
    
//     /* Compute final Rayleigh quotient: lambda ~ x^T*(A*x) */
//     localMatVec(A, x_global, y_local);
//     double local_dot = 0.0;
//     for (int i = 0; i < A->n_local; i++){
//         int global_row = A->row_offset + i;
//         local_dot += x_global[global_row] * y_local[i];
//     }
//     double global_dot = 0.0;
//     MPI_Allreduce(&local_dot, &global_dot, 1, MPI_DOUBLE, MPI_SUM, comm);
//     if (rank == 0) {
//         printf("Final estimated largest eigenvalue ~ %.8f\n", global_dot);
//     }
//     free(y_local);
// }

// /*---------------------------
//   main:
//   Rank 0 reads the full matrix, distributes it,
//   then runs parallel power iteration.
// ----------------------------*/
// int main(int argc, char **argv)
// {
//     MPI_Init(&argc, &argv);
//     int rank, size;
//     MPI_Comm_rank(MPI_COMM_WORLD, &rank);
//     MPI_Comm_size(MPI_COMM_WORLD, &size);
    
//     const char *matrixFile = "data/cfd1/cfd1.mtx"; 
//     //const char *matrixFile = "data/bcsstk03/bcsstk03.mtx"; 
//      //const char *matrixFile = "data/1138_bus.mtx"; 
//     int max_iter = 100;
    
//     csr_matrix Afull;
//     if (rank == 0) {
//         readMMFSerial(matrixFile, &Afull);
//     }
    
//     csr_block A_local;
//     memset(&A_local, 0, sizeof(csr_block));
//     distributeCSR(&Afull, &A_local, MPI_COMM_WORLD);
    
//     if (rank == 0) {
//         free(Afull.row_ptr);
//         free(Afull.col_idx);
//         free(Afull.val);
//     }
    
//     double *x_global = (double*) malloc(A_local.n_global * sizeof(double));
//     parallelPowerIteration(&A_local, x_global, max_iter, MPI_COMM_WORLD);
    
//     free(A_local.row_ptr);
//     free(A_local.col_idx);
//     free(A_local.val);
//     free(x_global);
    
//     MPI_Finalize();
//     return 0;
// }


#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "mmio.h" 



typedef struct {
    int n;          // number of rows
    int m;          // number of columns
    int *row_ptr;   // size: n+1
    int *col_idx;   // size: number of nonzeros
    double *val;    // size: number of nonzeros
} csr_matrix;

/

typedef struct {
    int n_global;   // global dimension (number of rows in full matrix)
    int n_local;    // number of rows on this rank
    int row_offset; // starting global row index for this rank
    int *row_ptr;   // local row_ptr (size: n_local+1)
    int *col_idx;   // local column indices (size: local nnz)
    double *val;    // local nonzero values (size: local nnz)
} csr_block;



void readMMF(const char *filename, csr_matrix *A) {
    MM_typecode matcode;
    FILE *f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "Error opening file %s\n", filename);
        exit(1);
    }
    
    // Read banner
    if (mm_read_banner(f, &matcode) != 0) {
        printf("Could not process Matrix Market banner.\n");
        exit(1);
    }
    
    // Check type: must be sparse, real, and symmetric.
    if (!mm_is_sparse(matcode) || !mm_is_real(matcode) || !mm_is_symmetric(matcode)) {
        printf("Matrix must be sparse, real, and symmetric.\n");
        exit(1);
    }
    
    // Read dimensions and number of entries in the triangular part.
    int M, N, nz;
    if (mm_read_mtx_crd_size(f, &M, &N, &nz) != 0) {
        printf("Error reading matrix size.\n");
        exit(1);
    }
    
    // Allocate temporary COO arrays.
    int *I = (int*)malloc(nz * sizeof(int));
    int *J = (int*)malloc(nz * sizeof(int));
    double *V = (double*)malloc(nz * sizeof(double));
    
    // Read the (i, j, value) lines and convert indices from 1-based to 0-based.
    for (int i = 0; i < nz; i++) {
        fscanf(f, "%d %d %lf", &I[i], &J[i], &V[i]);
        I[i]--;
        J[i]--;
    }
    fclose(f);
    
    // Count the number of off-diagonals (to be mirrored).
    int offDiag = 0;
    for (int k = 0; k < nz; k++) {
        if (I[k] != J[k])
            offDiag++;
    }
    int totalEntries = nz + offDiag;
    
    // Allocate CSR arrays.
    A->n = M;
    A->m = N;
    A->row_ptr = (int*)malloc((M + 1) * sizeof(int));
    A->col_idx = (int*)malloc(totalEntries * sizeof(int));
    A->val     = (double*)malloc(totalEntries * sizeof(double));
    
    // Use a temporary count array to compute the number of entries per row.
    int *count = (int*)calloc(M, sizeof(int));
    for (int k = 0; k < nz; k++) {
        count[I[k]]++;
        if (I[k] != J[k])
            count[J[k]]++;
    }
    // Build the row_ptr array with a prefix sum.
    A->row_ptr[0] = 0;
    for (int i = 0; i < M; i++) {
        A->row_ptr[i+1] = A->row_ptr[i] + count[i];
    }
    free(count);
    
    // Debug: check that total entries matches.
    if (A->row_ptr[M] != totalEntries) {
        printf("Warning: row_ptr[M] (%d) does not equal totalEntries (%d).\n", A->row_ptr[M], totalEntries);
    }
    
    // Allocate a temporary "current" array to track insertion indices.
    int *current = (int*)malloc(M * sizeof(int));
    memcpy(current, A->row_ptr, M * sizeof(int));
    
    // Fill in col_idx and val.
    for (int k = 0; k < nz; k++) {
        int r = I[k];
        int c = J[k];
        double v = V[k];
        
        int destPos = current[r];
        A->col_idx[destPos] = c;
        A->val[destPos] = v;
        current[r]++;
        
        if (r != c) {
            destPos = current[c];
            A->col_idx[destPos] = r;
            A->val[destPos] = v;
            current[c]++;
        }
    }
    
    free(current);
    free(I);
    free(J);
    free(V);
    
    printf("Matrix read successfully in full symmetric form.\n");
}



void localMatVec(const csr_block *A, const double *x_global, double *y_local) {
    for (int i = 0; i < A->n_local; i++){
        double sum = 0.0;
        int start = A->row_ptr[i];
        int end = A->row_ptr[i+1];
        for (int j = start; j < end; j++){
            int col = A->col_idx[j];
            sum += A->val[j] * x_global[col];
        }
        y_local[i] = sum;
    }
}



double vector_norm(const double *v, int n) {
    double sum = 0.0;
    for (int i = 0; i < n; i++){
        sum += v[i] * v[i];
    }
    return sqrt(sum);
}


double dot_product(const double *a, const double *b, int n) {
    double sum = 0.0;
    for (int i = 0; i < n; i++){
        sum += a[i] * b[i];
    }
    return sum;
}

void distributeCSR(const csr_matrix *Afull, csr_block *Ablock, MPI_Comm comm) {
    int rank, size;
    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &size);
    
    int n_global;
    if (rank == 0)
        n_global = Afull->n;
    else
        n_global = 0;
    MPI_Bcast(&n_global, 1, MPI_INT, 0, comm);
    
    int rows_per_proc = (n_global + size - 1) / size;
    int start_row = rank * rows_per_proc;
    int end_row = (rank + 1) * rows_per_proc;
    if (end_row > n_global) end_row = n_global;
    Ablock->n_global = n_global;
    Ablock->n_local = end_row - start_row;
    Ablock->row_offset = start_row;
    
    int local_nnz;
    if (rank == 0) {
        local_nnz = 0;
        for (int r = start_row; r < end_row; r++){
            local_nnz += Afull->row_ptr[r+1] - Afull->row_ptr[r];
        }
    } else {
        MPI_Recv(&local_nnz, 1, MPI_INT, 0, 99, comm, MPI_STATUS_IGNORE);
    }
    
    /* Allocate at least one element if local_nnz==0 */
    Ablock->row_ptr = (int*) malloc((Ablock->n_local + 1) * sizeof(int));
    Ablock->col_idx = (int*) malloc((local_nnz > 0 ? local_nnz : 1) * sizeof(int));
    Ablock->val     = (double*) malloc((local_nnz > 0 ? local_nnz : 1) * sizeof(double));
    
    if (rank == 0) {
        int prefix = 0;
        Ablock->row_ptr[0] = 0;
        for (int i = 0; i < Ablock->n_local; i++){
            int r = start_row + i;
            int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
            prefix += row_len;
            Ablock->row_ptr[i+1] = prefix;
        }
        int idx = 0;
        for (int r = start_row; r < end_row; r++){
            int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
            int pos = Afull->row_ptr[r];
            memcpy(&Ablock->col_idx[idx], &Afull->col_idx[pos], row_len * sizeof(int));
            memcpy(&Ablock->val[idx], &Afull->val[pos], row_len * sizeof(double));
            idx += row_len;
        }
        /* Send blocks to other processes */
        for (int other = 1; other < size; other++) {
            int o_start = other * rows_per_proc;
            int o_end = (other+1) * rows_per_proc;
            if (o_end > n_global) o_end = n_global;
            int o_n_local = o_end - o_start;
            int o_local_nnz = 0;
            for (int r = o_start; r < o_end; r++){
                o_local_nnz += Afull->row_ptr[r+1] - Afull->row_ptr[r];
            }
            MPI_Send(&o_local_nnz, 1, MPI_INT, other, 99, comm);
            int *tmp_row_ptr = (int*) malloc((o_n_local + 1) * sizeof(int));
            tmp_row_ptr[0] = 0;
            int prefix_o = 0;
            for (int i = 0; i < o_n_local; i++){
                int r = o_start + i;
                int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
                prefix_o += row_len;
                tmp_row_ptr[i+1] = prefix_o;
            }
            int *tmp_col = (int*) malloc((o_local_nnz > 0 ? o_local_nnz : 1) * sizeof(int));
            double *tmp_val = (double*) malloc((o_local_nnz > 0 ? o_local_nnz : 1) * sizeof(double));
            int idx2 = 0;
            for (int r = o_start; r < o_end; r++){
                int row_len = Afull->row_ptr[r+1] - Afull->row_ptr[r];
                int pos = Afull->row_ptr[r];
                memcpy(&tmp_col[idx2], &Afull->col_idx[pos], row_len * sizeof(int));
                memcpy(&tmp_val[idx2], &Afull->val[pos], row_len * sizeof(double));
                idx2 += row_len;
            }
            MPI_Send(tmp_row_ptr, o_n_local+1, MPI_INT, other, 100, comm);
            MPI_Send(tmp_col, o_local_nnz, MPI_INT, other, 101, comm);
            MPI_Send(tmp_val, o_local_nnz, MPI_DOUBLE, other, 102, comm);
            free(tmp_row_ptr);
            free(tmp_col);
            free(tmp_val);
        }
    } else {
        MPI_Recv(Ablock->row_ptr, Ablock->n_local+1, MPI_INT, 0, 100, comm, MPI_STATUS_IGNORE);
        MPI_Recv(Ablock->col_idx, local_nnz, MPI_INT, 0, 101, comm, MPI_STATUS_IGNORE);
        MPI_Recv(Ablock->val, local_nnz, MPI_DOUBLE, 0, 102, comm, MPI_STATUS_IGNORE);
    }
}


void parallelPowerIteration(const csr_block *A, double *x_global, int max_iter, MPI_Comm comm) {
    int rank;
    MPI_Comm_rank(comm, &rank);
    double *y_local = (double*) malloc(A->n_local * sizeof(double));
    
    // Initialize x_global on rank 0 and broadcast.
    if (rank == 0) {
        srand((unsigned)time(NULL));
        for (int i = 0; i < A->n_global; i++){
            x_global[i] = (double)rand() / RAND_MAX;
        }
    }
    MPI_Bcast(x_global, A->n_global, MPI_DOUBLE, 0, comm);
    
    // Normalize x_global.
    double local_sum = 0.0;
    for (int i = 0; i < A->n_global; i++){
        local_sum += x_global[i] * x_global[i];
    }
    double global_sum = 0.0;
    MPI_Allreduce(&local_sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, comm);
    double norm_init = sqrt(global_sum);
    for (int i = 0; i < A->n_global; i++){
        x_global[i] /= norm_init;
    }
    MPI_Bcast(x_global, A->n_global, MPI_DOUBLE, 0, comm);
    
    for (int iter = 0; iter < max_iter; iter++){
        // Compute y_local = A_local * x_global.
        localMatVec(A, x_global, y_local);
        
        // Compute the norm of y_local.
        double local_norm_sq = 0.0;
        for (int i = 0; i < A->n_local; i++){
            local_norm_sq += y_local[i] * y_local[i];
        }
        double global_norm_sq = 0.0;
        MPI_Allreduce(&local_norm_sq, &global_norm_sq, 1, MPI_DOUBLE, MPI_SUM, comm);
        double y_norm = sqrt(global_norm_sq);
        
        // Update the local portion of x_global.
        for (int i = 0; i < A->n_local; i++){
            int global_row = A->row_offset + i;
            x_global[global_row] = y_local[i] / y_norm;
        }
        MPI_Bcast(x_global, A->n_global, MPI_DOUBLE, 0, comm);
    }
    
    // Compute final Rayleigh quotient: lambda ~ x^T*(A*x)
    localMatVec(A, x_global, y_local);
    double local_dot = 0.0;
    for (int i = 0; i < A->n_local; i++){
        int global_row = A->row_offset + i;
        local_dot += x_global[global_row] * y_local[i];
    }
    double global_dot = 0.0;
    MPI_Allreduce(&local_dot, &global_dot, 1, MPI_DOUBLE, MPI_SUM, comm);
    if (rank == 0) {
        printf("Final estimated largest eigenvalue ~ %.8f\n", global_dot);
    }
    free(y_local);
}



int main(int argc, char **argv) {

    
    if(argc < 3){
        printf("Usage: %s <matrix-file>\n",argv[0]);
        exit(1);
    }
    //printf("0\n");



   char *matrixFile = argv[1];
   int max_iter = atoi(argv[2]);



    MPI_Init(&argc, &argv);
    
    int rank, size;

    //lets count the time
    double start = MPI_Wtime();

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
   // const char *matrixFile = "data/cfd1/cfd1.mtx";  // Adjust path as needed.
    ///readMMF("data/bcsstk03/bcsstk03.mtx",&A);
    //const char *matrixFile = "data/bcsstk03/bcsstk03.mtx";
    //const char *matrixFile = "data/1138_bus.mtx";
    //int max_iter = 20;

    
    
    csr_matrix Afull;
    if (rank == 0) {
        readMMF(matrixFile, &Afull);
    }
    
    csr_block A_local;
    memset(&A_local, 0, sizeof(csr_block));
    distributeCSR(&Afull, &A_local, MPI_COMM_WORLD);
    
    if (rank == 0) {
        free(Afull.row_ptr);
        free(Afull.col_idx);
        free(Afull.val);
    }
    
    double *x_global = (double*) malloc(A_local.n_global * sizeof(double));
    parallelPowerIteration(&A_local, x_global, max_iter, MPI_COMM_WORLD);

    double end = MPI_Wtime();
    if(rank == 0){
        printf("Time taken: %f\n",end-start);
    }

    
    free(A_local.row_ptr);
    free(A_local.col_idx);
    free(A_local.val);
    free(x_global);
    
    MPI_Finalize();
    return 0;
}
