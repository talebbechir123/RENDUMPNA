import matplotlib.pyplot as plt

# Hard-coded data: number of MPI processes vs. execution time (seconds)
processes = [1, 2, 4, 8]
times = [0.000329, 0.000329, 0.000362, 0.000425]

plt.figure(figsize=(8, 6))
plt.plot(processes, times, marker='o', linestyle='-', color='blue', label='Execution Time')

plt.xlabel("Number of MPI Processes")
plt.ylabel("Time (seconds)")
plt.title("Execution Time vs. MPI Process Count for bcsstk03")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
