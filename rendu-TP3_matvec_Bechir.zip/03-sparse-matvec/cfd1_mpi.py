import matplotlib.pyplot as plt

# Hard-coded data: number of MPI processes and the approximated spectral radius.
# You reported:
# 1 process: 0.663083
# 2 processes: 0.517018
# 4 processes: 0.462275
# 8 processes: 0.439877
processes = [1, 2, 4, 8]
eigenvalues = [0.663083, 0.517018, 0.462275, 0.439877]

plt.figure(figsize=(8, 6))
plt.plot(processes, eigenvalues, marker='o', linestyle='-', color='blue', label='Approximated Spectral Radius')
plt.xlabel("Number of MPI Processes")
plt.ylabel("Time (seconds)")
plt.title("Effect of MPI Process Count on Approximated Spectral Radius (cfd1)")
plt.grid(True)
plt.legend()

# Optionally, if you want a logarithmic scale on the y-axis, uncomment the next line:
# plt.yscale('log')

plt.tight_layout()
plt.show()
