import numpy as np
import matplotlib.pyplot as plt

# Load the approximated eigenvalues from bss.txt
data = np.loadtxt("bss.txt")

# Generate iteration numbers (assuming an increment of 20 per iteration)
iterations = np.arange(20, 20*(len(data)+1), 20)

# Gershgorin upper bound (given)
gersh_bound = 211874080895.923004

plt.figure(figsize=(8, 6))
plt.plot(iterations, data, marker='o', linestyle='-', color='blue',
         label='Power Iteration Approximation')
plt.axhline(y=gersh_bound, color='red', linestyle='--',
            label=f'Gershgorin Upper Bound ({gersh_bound:.3f})')

plt.xlabel("Iteration")
plt.ylabel("Approximated Spectral Radius")
plt.title("Evolution of Approximated Spectral Radius for bss.txt (Log Scale)")
plt.legend()
plt.grid(True)

# Use a logarithmic scale on the y-axis.
plt.yscale("log")
plt.tight_layout()
plt.show()
