#ifndef GMRES_H
#define GMRES_H

#include "CSRMatrix.h"
#include <vector>

/**
 * Solve A*x = b using the GMRES algorithm with restart.
 *
 * @param A         CSRMatrix representing the system (can be non-symmetric).
 * @param b         Right-hand side vector.
 * @param x         On input: initial guess; on output: computed solution.
 * @param restart   Dimension of the Krylov subspace before a restart.
 * @param max_iter  Maximum total iterations allowed.
 * @param tol       Convergence tolerance (based on the residual norm).
 */
void gmresCSR(const CSRMatrix &A,
              const std::vector<double> &b,
              std::vector<double> &x,
              int restart,
              int max_iter,
              double tol);

#endif // GMRES_H
