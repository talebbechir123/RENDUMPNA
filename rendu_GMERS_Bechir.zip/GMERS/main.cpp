#include <iostream>
#include <vector>
#include <chrono>
#include <cmath>

// Declarations for CG, Jacobi, Gauss-Seidel
void conjugateGradientCSR(const class CSRMatrix &A,
                          const std::vector<double> &b,
                          std::vector<double> &x,
                          int max_iter,
                          double tol);

#include "iterative_methods.h"
#include "CSRMatrix.h"
#include "Laplacian2D.h"
#include "gmres.h"  // Include the GMRES header

int main() {
    // Suppose we want a Laplacian for a 10x10 grid => dimension = 100
    int size = 10;

    // Build the matrix
    CSRMatrix A = createLaplacian2D(size);

    // Build the RHS vector b, for example, all ones:
    std::vector<double> b(A.n, 1.0);

    // Prepare an initial guess x = zero
    std::vector<double> x(A.n, 0.0);

    // Set maximum iterations and tolerance
    int max_iter = 1000;
    double tol = 1e-10;

    // 1) Test Conjugate Gradient
    auto start = std::chrono::high_resolution_clock::now();
    conjugateGradientCSR(A, b, x, max_iter, tol);
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> dur_cg = end - start;
    std::cout << "CG finished in " << dur_cg.count() << " seconds.\n";

    // 2) Reset x, test Jacobi
    std::fill(x.begin(), x.end(), 0.0);
    start = std::chrono::high_resolution_clock::now();
    jacobiCSR(A, b, x, max_iter, tol);
    end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> dur_jacobi = end - start;
    std::cout << "Jacobi finished in " << dur_jacobi.count() << " seconds.\n";

    // 3) Reset x, test Gauss-Seidel
    std::fill(x.begin(), x.end(), 0.0);
    start = std::chrono::high_resolution_clock::now();
    gaussSeidelCSR(A, b, x, max_iter, tol);
    end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> dur_gs = end - start;
    std::cout << "Gauss-Seidel finished in " << dur_gs.count() << " seconds.\n";

    // 4) Reset x, test GMRES with restart
    std::fill(x.begin(), x.end(), 0.0);
    int restart = 50;  // Adjust the restart parameter as needed
    start = std::chrono::high_resolution_clock::now();
    gmresCSR(A, b, x, restart, max_iter, tol);
    end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> dur_gmres = end - start;
    std::cout << "GMRES finished in " << dur_gmres.count() << " seconds.\n";

    return 0;
}
