#include "gmres.h"
#include <vector>
#include <cmath>
#include <iostream>

// Helper function: compute dot product of two vectors.
static double dot(const std::vector<double>& a, const std::vector<double>& b) {
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); i++){
        sum += a[i] * b[i];
    }
    return sum;
}

// Helper function: compute 2-norm of a vector.
static double norm(const std::vector<double>& a) {
    return std::sqrt(dot(a, a));
}

// GMRES implementation using restarted Arnoldi and Givens rotations.
void gmresCSR(const CSRMatrix &A,
              const std::vector<double> &b,
              std::vector<double> &x,
              int restart,
              int max_iter,
              double tol)
{
    int n = A.n;
    if(b.size() != n || x.size() != n) {
        std::cerr << "Error: dimension mismatch in gmresCSR.\n";
        return;
    }

    // r = b - A*x
    std::vector<double> r(n, 0.0), Ax(n, 0.0);
    A.multiply(x, Ax);
    for (int i = 0; i < n; i++){
        r[i] = b[i] - Ax[i];
    }
    double beta = norm(r);
    double rnorm = beta;
    int iter = 0;

    // Outer loop: restart cycles
    while(iter < max_iter && rnorm > tol) {
        // Allocate space for Krylov basis (V) and Hessenberg matrix (H)
        std::vector< std::vector<double> > V(restart + 1, std::vector<double>(n, 0.0));
        std::vector< std::vector<double> > H(restart + 1, std::vector<double>(restart, 0.0));

        // Arrays to store Givens rotation coefficients.
        std::vector<double> cs(restart, 0.0), sn(restart, 0.0);
        // g stores the transformed right-hand side of the least-squares problem.
        std::vector<double> g(restart + 1, 0.0);

        // Initialize the first Krylov vector
        for (int i = 0; i < n; i++){
            V[0][i] = r[i] / beta;
        }
        g[0] = beta;

        int i;
        // Arnoldi process to build the Krylov subspace
        for (i = 0; i < restart && iter < max_iter; i++) {
            // Compute w = A * V[i]
            std::vector<double> w(n, 0.0);
            A.multiply(V[i], w);

            // Modified Gram-Schmidt orthogonalization
            for (int k = 0; k <= i; k++) {
                H[k][i] = dot(w, V[k]);
                for (int j = 0; j < n; j++){
                    w[j] -= H[k][i] * V[k][j];
                }
            }
            H[i+1][i] = norm(w);

            // Check for breakdown of Arnoldi process
            if (H[i+1][i] < 1e-12) {
                i++; // Adjust i to the actual number of basis vectors computed
                break;
            }

            // Normalize w to form the next basis vector
            for (int j = 0; j < n; j++){
                V[i+1][j] = w[j] / H[i+1][i];
            }

            // Apply all previously computed Givens rotations to H(:,i)
            for (int k = 0; k < i; k++){
                double temp = cs[k] * H[k][i] + sn[k] * H[k+1][i];
                H[k+1][i] = -sn[k] * H[k][i] + cs[k] * H[k+1][i];
                H[k][i] = temp;
            }

            // Compute the i-th Givens rotation
            double delta = std::sqrt(H[i][i]*H[i][i] + H[i+1][i]*H[i+1][i]);
            if(delta == 0.0){
                cs[i] = 1.0;
                sn[i] = 0.0;
            } else {
                cs[i] = H[i][i] / delta;
                sn[i] = H[i+1][i] / delta;
            }
            // Apply the rotation
            H[i][i] = cs[i] * H[i][i] + sn[i] * H[i+1][i];
            g[i+1] = -sn[i] * g[i];
            g[i] = cs[i] * g[i];

            rnorm = std::fabs(g[i+1]);
            iter++;  // Count inner iteration

            // Early convergence check for the current cycle
            if (rnorm < tol)
                break;
        }

        // Solve the least-squares problem (an upper triangular system)
        std::vector<double> y(i, 0.0);
        for (int k = i - 1; k >= 0; k--){
            double sum = 0.0;
            for (int j = k + 1; j < i; j++){
                sum += H[k][j] * y[j];
            }
            y[k] = (g[k] - sum) / H[k][k];
        }

        // Update the solution: x = x + V(:,1:i)*y
        for (int j = 0; j < i; j++){
            for (int k = 0; k < n; k++){
                x[k] += V[j][k] * y[j];
            }
        }

        // Compute new residual r = b - A*x and its norm
        A.multiply(x, Ax);
        for (int j = 0; j < n; j++){
            r[j] = b[j] - Ax[j];
        }
        beta = norm(r);
        rnorm = beta;
        // Optionally, you might print the residual here:
        // std::cout << "Restart cycle complete: residual norm = " << rnorm << std::endl;
    }
}
